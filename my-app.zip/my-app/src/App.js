// import { createContext } from 'react';
import './App.css';

// import FormComponent from './HandlingEventsForms/FormComponent';
// import ClassBase from './components/ClassBase';
// import FunctionBase from './components/FunctionBase';
// import ClassComponent from './LifeCycle/ClassComponent';
// import { APIDataRender } from './ListAPICalls/APIDataRender';
// import UseStateHook from './Hookes/UseStateHook';
// import UseEffectHook from './Hookes/UseEffectHook';
// import ContextAndUseContextHook from './Hookes/ContextAndUseContextHook';
// import UseReducerHook from './Hookes/UseReducerHook';
// import UseRefHook from './Hookes/UseRefHook';

// export const Context = createContext('light');
// console.log(Context)




function App() {
  return (

    <div className='App'></div>

    // <Context.Provider value='green'>
    //   <div className="App">
    //     hello world

    //     {/* <ClassBase/>
    //  <br/>
    //  <br/>
    //  <br/>
    //  <br/>
    //  <FunctionBase></FunctionBase> */}
    //     {/* <ClassComponent/> */}

    //     {/* <FormComponent/> */}
    //     {/* <APIDataRender/> */}
    //     {/* <UseStateHook/> */}
    //     {/* <UseEffectHook/> */}

    //     {/* <ContextAndUseContextHook/> */}

    //     {/* <UseReducerHook /> */}

    //     <UseRefHook />
    //   </div></Context.Provider>
  );
}

export default App;
