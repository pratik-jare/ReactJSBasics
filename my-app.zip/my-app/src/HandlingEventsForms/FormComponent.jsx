import React, { Component } from 'react';

class FormComponent extends Component {



    state = {
        formData: {
            name: '',
            age: 0
        },
        finalFormData: {}
    }

    handleSubmit = (event) => {
        event.preventDefault()
        console.log(this.state.formData);

        const { formData } = this.state;

        this.setState(preState => ({
            ...preState,
            finalFormData: {
                ...preState,
                ...formData
            },
            formData: {
                name: '',
                age: 0
            },

        }))


    }

    handleNameChange = (event) => {
        const { value } = event.target;

        this.setState((prevState) => ({
            formData: {
                ...prevState.formData,
                name: value
            }
        }))
    }

    handleAgeChange = (event) => {
        const { value } = event.target;

        this.setState(prevState => ({
            formData: {
                ...prevState.formData,
                age: value
            }
        }))
    }


    render() {
        console.log(this.state);
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <input type="text" name='name' placeholder='name'
                        value={this.state.formData.name}
                        onChange={this.handleNameChange}
                    />

                    <input type="number" name='age' placeholder='age'
                        value={this.state.formData.age}
                        onChange={this.handleAgeChange} />

                    <button type='submit' aria-label='submit'> submit</button>
                </form>
                final data is {this.state.finalFormData.name} and  {this.state.finalFormData.age} 
            </div>
        );
    }
}

export default FormComponent;