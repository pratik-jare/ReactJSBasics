import React, { useContext } from 'react'
import { Context } from './../App';

function ContextAndUseContextHook() {


    const getValueFromContext = useContext(Context)

    console.log(getValueFromContext);


    return (
        <div>ContextAndUseContextHook
            <button style={{ backgroundColor: getValueFromContext}}> click</button>
        </div>

    )
}

export default ContextAndUseContextHook