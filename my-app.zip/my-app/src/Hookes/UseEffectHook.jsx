import React, { useEffect, useState } from 'react'
// hooks used in functional base components 

function UseEffectHook() {

    const [count, setCount] = useState(0); // initial state
    const [flag, setFlag] = useState(false); // initial state



    console.log(count)

    const handleClick = () => {
        setCount(count + 1);
    }

    useEffect(()=>{
        console.log('effect is called once on page load')
    },[]) // like component did mount is class component this used in functional component.

    

    useEffect(()=>{
        console.log('effect is called once on page load')
        if(count === 5) {
            setFlag(true)
        }
    },[count]) 
    // like component did update is class component this used in functional component.
    // just checking previous state

     useEffect(() => {
        return () => {
            console.log('unmounted');
        }
     }) // this effect will return as callback method, like component will unmount in class base component.


    return (
        <div>
            UseEffectHook

            <button onClick={handleClick}> click </button>

            counter value is {count}

            {
                flag && <p> Hello world</p>
            }
        </div>

    )
}

export default UseEffectHook