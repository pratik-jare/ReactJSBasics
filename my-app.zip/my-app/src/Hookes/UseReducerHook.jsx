import React, { useReducer } from 'react'

const initialState = {
    flag: false
}

const reducer = (state, action) => {
    switch (action.type) {
        case 'TOGGLE_BTN':
            console.log(state, action);
            return {
                ...state,
                flag: !state.flag
            };
        default:

            return state;
    }
}

function UseReducerHook() {

    const [state, dispatch] = useReducer(reducer, initialState)

    console.log(state);

    return (
        <div>UseReducerHook


            <button type="submit" onClick={() => dispatch({ type: 'TOGGLE_BTN' })}>click</button>
        </div>

    )
}

export default UseReducerHook