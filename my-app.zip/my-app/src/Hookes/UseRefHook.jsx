// useRefHook and Dom element

import React, { useRef } from 'react'
import { useEffect } from 'react';

function UseRefHook() {

    const inputRef = useRef(null);
    console.log(inputRef)

    // const handleFocus = () => {
    //     inputRef.current.focus()
    // }

    useEffect(()=>{
        inputRef.current.focus()
    })



    return (
        <div>UseRefHook

            <input ref={inputRef} type="text" name="name" placeholder='name' />
            {/* <button onClick={handleFocus}> Submit</button> */}
        </div>
    )
}

export default UseRefHook