import React, { useState } from 'react'
// hooks used in functional base components 

function UseStateHook() {

    const [count, setCount] = useState(0); // initial state



    console.log(count)

    const handleClick = () => {
        setCount(count + 1);
    }


    return (
        <div>
            UseStateHook

            <button onClick={handleClick}> click </button>

            counter value is {count}
        </div>

    )
}

export default UseStateHook