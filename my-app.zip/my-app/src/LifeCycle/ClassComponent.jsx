import React, { Component } from 'react'

export class ClassComponent extends Component {

  state = {
    count: 0,
    flag: false,
  }


  handleClick = () => {
    const { count } = this.state;

    this.setState({
      count: count + 1
    }, () => {
      console.log(this.state)
    })
  }

  componentDidMount() {
    // if you have to call api and show the data.
    console.log('component is mounted!!! ')
  }

  componentDidUpdate(prevProps, prevState) {
    // for condition checking values of state and props 
    console.log(prevState, this.state)
    if (prevState && prevState.count !== this.state.count && this.state.count === 10) {
      this.setState({
        flag: true
      })
    }
  }

  componentWillUnmount() {
    // Called immediately before a component is destroyed. 
    // Perform any necessary cleanup in this method, such as cancelled network requests, or
    //  cleaning up any DOM elements created in componentDidMount.
    //  for cleaning storage local storage cookies etc.
  }

  render() {
    return (
      <div > Class  LifeCycle  Component!!!
        <button onClick={this.handleClick}> click </button>

        {
          this.state.count === 5 && 'count is 5'
        }

        {
          this.state.flag && <p> flag is true</p>
        }


      </div>
    )
  }
}

export default ClassComponent