import React from 'react'

function PropExample(props) {
    console.log(props);
    const { flag, data, parentComponentHandler, getValueForParent } = props;

    const handleClick = () => {
        const count = 5;
        getValueForParent(count + 1);
    }

    return (

        <div>
            {
                flag ? data : 'flag false'
            }
            <button onClick={parentComponentHandler}>click</button>
            <br />
            <button onClick={handleClick}>handle click</button>
        </div>
    )
}

export default PropExample;