
import React, { Component } from "react";

class classBase extends Component {

    // state  = {
    // write all state properties inside of this
    // }

    state = {
        count: 0, // initial value of count property
    }

    // constructor(props) {
    //     super(props);
    //     this.state = {
    //         // or write state properties inside this
    //         count: 0,
    //     }
    //     this.handleClick = this.handleClick.bind(this)
    // }


    handleClick = () => {
        // this.state.count  = this.state.count + 1; // directly mutating state is wrong use set state property 
        const { count } = this.state;

        this.setState({
            count: count + 1
        }, () => {
            console.log(this.state)
        })
    }

    render() {
        console.log(this.state)
        return (
            <div > Class Based Component!!!

                {
                    this.state.count === 5 && 'count is 5'
                }


                <button onClick={this.handleClick}> click class component</button>
            </div>
        );
    }
}

export default classBase;