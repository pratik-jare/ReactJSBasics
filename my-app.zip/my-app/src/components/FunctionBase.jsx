import React from 'react';
import PropExample from '../PropsExamples';

const Child = () => {
    return (
        <p> child function </p>
    )
}

function FunctionBase() {

    const parentComponentHandler = () => {
        console.log('hello from parent');
    }

    const getValueForParent = (value) => {
        console.log(value);
    }


    return (
        <div>
            <PropExample
                getValueForParent={getValueForParent}
                parentComponentHandler={parentComponentHandler} flag={false} data="prop data" />
            FunctionBase
            <Child />
        </div>
    )
}

export default FunctionBase